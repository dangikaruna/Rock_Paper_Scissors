let userScore = 0;
let compScore = 0;
 let user_Score=document.querySelector('#user-score')
 let comp_Score=document.querySelector('#comp-score')
let msg= document.querySelector('#msg')
function showWinner(userWin, userChoice, compChoice){
    if(userWin== true){
        userScore++;
        user_Score.innerText=userScore
        msg.innerText=`You Win! Your ${userChoice} beats ${compChoice}.`
        msg.style.backgroundColor="green"
    }
    else{
        compScore++;
        comp_Score.innerText=compScore
        msg.innerText=`You Lose. ${compChoice} beats your ${userChoice}.`
        msg.style.backgroundColor="red"
    }
}

function playGame(userChoice, compChoice) {
  if (userChoice === compChoice) {
    msg.innerText = "Game Was Draw.";
    msg.style.backgroundColor= "#081b31"
  } else {
    let userWin = true;
    //paper scessio
    if (userChoice === "rock") {
      //paper scessior
      userWin = compChoice === "paper" ? false : true;
    }
    else if (userChoice === "paper") {
      //rock scessior
      userWin = compChoice === "scissors" ? false : true;
    }
   else {
      //rock paper
      userWin = compChoice === "rock" ? false : true;
    }

    showWinner(userWin, userChoice,compChoice);
  }
}

function genCompChoice() {
  const allOption = ["rock", "paper", "scissors"];
  compIdx = Math.floor(Math.random() * 3);
  console.log(allOption[compIdx]);
  return allOption[compIdx];
}

function userClick(userChoice) {
  console.log(userChoice);
  const compChoice = genCompChoice();
  playGame(userChoice, compChoice);
}

const choices = document.querySelectorAll(".choice");

choices.forEach((choice) => {
  console.log(choice);
  choice.addEventListener("click", () => {
    let userChoice = choice.getAttribute("id");
    console.log("choice clicked", userChoice);
    userClick(userChoice);
  });
});
